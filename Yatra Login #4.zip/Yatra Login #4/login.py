import time
from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class LoginPage:
    def __init__(self):
        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        self.driver.maximize_window()
        self.driver.get(
            "https://secure.yatra.com/social/common/yatra/signin.htm?source=mybookings&returnUrl=https%3A%2F%2Fsecure.yatra.com%2Fmanage-bookings%2Fallbookings"
        )

    def login(self, email):
        # Wait until the login input is visible
        login_input = WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//input[@id='login-input']"))
        )
        login_input.send_keys(email)

        # Wait until the continue button is clickable
        continue_btn = WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@id='login-continue-btn']"))
        )
        continue_btn.click()

        print("Email entered and continue button clicked successfully!")

# Usage
run = LoginPage()
run.login("TEST@gmail.com")
